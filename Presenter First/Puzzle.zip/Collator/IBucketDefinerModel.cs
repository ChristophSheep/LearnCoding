namespace Collator
{
  public interface IBucketDefinerModel
  {
    IBucket[] GetBuckets();
  }
}

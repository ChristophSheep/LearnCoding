namespace Collator
{
  public interface IBucket
  {
  }
}

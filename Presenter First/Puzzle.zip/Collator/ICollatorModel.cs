namespace Collator
{
  public interface ICollatorModel
  {
    void Collate();
  }
}

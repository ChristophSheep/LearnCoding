namespace wsm.Puzzle
{
  public interface IModel
  {
    
  }
}

namespace wsm.Puzzle
{
	public class <%= name %>AdapterModel : I<%= name %>AdapterModel
	{
		public <%= name %>AdapterModel()
		{
		}
	}
}

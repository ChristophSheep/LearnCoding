namespace wsm.Puzzle
{
	public interface I<%= name %>Model 
	{
	}
}

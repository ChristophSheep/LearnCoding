namespace wsm.Puzzle
{
	public class <%= name %>Model : I<%= name %>Model
	{
		public <%= name %>Model()
		{
		}
	}
}

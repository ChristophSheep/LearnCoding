namespace BepHost
{
	public class <%= name %>
	{
		public <%= name %>()
		{
		}
	}
}

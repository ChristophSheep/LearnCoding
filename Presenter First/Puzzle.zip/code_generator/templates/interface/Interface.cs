namespace XRite.Retail.Utility.ColorantCombinator
{
	public interface %= iface_name %
	{
	}
}

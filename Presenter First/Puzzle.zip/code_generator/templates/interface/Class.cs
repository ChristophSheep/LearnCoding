namespace XRite.Retail.Utility.ColorantCombinator
{
	public class %= class_name %  %= iface_name %
	{
		public %= class_name %()
		{
		}
	}
}

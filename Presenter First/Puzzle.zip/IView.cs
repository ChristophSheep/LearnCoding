namespace wsm.Puzzle
{
  public interface IView
  {
    
  }
}

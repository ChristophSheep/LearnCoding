using System.Drawing;

namespace wsm.Puzzle
{
  public delegate void EventDelegate();
  public delegate void PointDelegate(Point point);
}
